import React from "react";
import { Card, CardBody } from "reactstrap";


const Contact = () =>{

return (

<Card color = "primary">

<CardBody>

<b>Anoop Pandey</b> <br/>
anoop31jan@gmail.com<br/>
CDC Pune India<br/>
8879344335


</CardBody>

</Card>


);

};
export default Contact;
